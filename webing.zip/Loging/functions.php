<?php

function check_login($con){
	
}